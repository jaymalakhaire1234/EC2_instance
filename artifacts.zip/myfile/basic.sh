#!/bin/bash

echo "this is bash scrit"

touch myfile.txt
echo "sampl_text" > myfile.txt

echo "End to scrit............"